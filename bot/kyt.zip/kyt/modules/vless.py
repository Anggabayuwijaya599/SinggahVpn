from kyt import *

# CREATE VLESS
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    async def create_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as pw:
            await event.respond("**Quota:**")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text
            
        # --- BAGIAN INI YANG DIUBAH (INPUT MANUAL) ---
        async with bot.conversation(chat) as exp:
            await event.respond("**Input Expired Day (Angka):**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        # ---------------------------------------------
            
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")
        
        # Variabel exp sekarang berisi angka string dari input user
        cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addvless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            # Konversi exp ke int untuk hitung tanggal
            later = today + DT.timedelta(days=int(exp))
            x = [x.group() for x in re.finditer("vless://(.*)",a)]
            print(x)
            # remarks = re.search("#(.*)",x[0]).group(1)
            # domain = re.search("@(.*?):",x[0]).group(1)
            uuid = re.search("vless://(.*?)@",x[0]).group(1)
            # path = re.search("path=(.*)&",x[0]).group(1)
            msg = f"""
**━━━━━━━━━━━━━━━━━**
** 🟢 Vless Account 🟢**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{user}`
**» Host Server  :** `{DOMAIN}`
**» Host XrayDNS :** `{HOST}`
**» User Quota   :** `{pw} GB`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» NetWork      :** `(WS) or (gRPC)`
**» User ID      :** `{uuid}`
**» Path Vless   :** `(/multi path)/vless `
**» Path Dynamic :** `http://BUG.COM/vless `
**» Pub Key      :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     : **
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
**» Link NTLS    :**
`{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link GRPC    :**
`{x[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vless-{user}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**»☎️ @SinggahPremium**
"""
            await event.respond(msg)
            
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vless_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

# CHECK / LIST VLESS
@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
    async def cek_vless_(event):
        await event.edit("`Processing List VLESS Account...`")
        
        # Script Bash langsung ditanam di dalam Python agar tidak perlu buat file .sh baru
        cmd = """
        FILE_DB="/etc/xray/config.json"
        USERS=$(grep -E "^#& " "$FILE_DB" | awk '{print $2}' | sort | uniq)
        count=0
        
        echo "━━━━━━━━━━━━━━━━━━━━━━━"
        echo "  🔵 LIST USER VLESS 🔵"
        echo "━━━━━━━━━━━━━━━━━━━━━━━"
        
        for AKUN in $USERS; do
            EXP_DATE=$(grep -E "^#& $AKUN " "$FILE_DB" | awk '{print $3}' | head -n 1)
            if [[ -z "$EXP_DATE" ]]; then EXP_DATE="Unlimited"; fi
            
            if [ -f "/etc/vless/$AKUN" ]; then
                bytes=$(cat "/etc/vless/$AKUN")
                if [[ $bytes -lt 1048576 ]]; then QUOTA="$(((bytes + 1023) / 1024)) KB"
                elif [[ $bytes -lt 1073741824 ]]; then QUOTA="$(((bytes + 1048575) / 1048576)) MB"
                else QUOTA="$(((bytes + 1073741823) / 1073741824)) GB"; fi
            else
                QUOTA="Unlimited"
            fi
            
            echo "👤 **Username :** \`$AKUN\`"
            echo "🗓 **Expired  :** \`$EXP_DATE\`"
            echo "📦 **Quota    :** \`$QUOTA\`"
            echo "──────────────────"
            ((count++))
        done
        
        echo "📊 **Total Akun :** $count Users"
        echo "━━━━━━━━━━━━━━━━━━━━━━━"
        """
        
        try:
            # Eksekusi command bash dan ambil outputnya
            a = subprocess.check_output(cmd, shell=True, executable='/bin/bash').decode("utf-8")
        except Exception as e:
            # Menambahkan tombol kembali jika terjadi error
            await event.respond(f"**Gagal memuat data:**\n`{e}`", buttons=[[Button.inline("‹ Kembali ›", "vless")]])
        else:
            # Menambahkan tombol kembali pada hasil list user yang sukses
            await event.respond(a, buttons=[[Button.inline("‹ Kembali ›", "vless")]])
            
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-delvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
	async def trial_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(3)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(3)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-trialvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**🟢 XRAY / VLESS 🟢**
**━━━━━━━━━━━━━━━━━**
**» Remarks     :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `Unlimited`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» Port NTLS   :** `80, 8080, 8081-9999`
**» NetWork     :** `(WS) or (gRPC)`
**» User ID     :** `{uuid}`
**» Path Vless  :** `(/multi path)/vless `
**» Path Dynamic:** `http://BUG.COM/vless `
**» Pub Key     :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS   : **
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
**» Link NTLS  :**
`{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link GRPC  :**
`{x[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Expired Until :** `{exp} Minutes`
**»☎️ @SinggahPremium**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" TRIAL VLESS ","trial-vless"),
Button.inline(" CREATE VLESS ","create-vless")],
[Button.inline(" CHECK VLESS ","cek-vless"),
Button.inline(" DELETE VLESS ","delete-vless")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** SINGGAH PREMIUM TUNNELING **
━━━━━━━━━━━━━━━━━━━━━━━ 
━━━━━━━━━━━━━━━━━━━━━━━ 
        **⚠️ MENU VLESS⚠️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🟢 **» Service:** `VLESS`
🟢 **» Hostname/IP:** `{DOMAIN}`
🟢 **» ISP:** `{z["isp"]}`
🟢 **» Country:** `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
