from kyt import *
import subprocess
import json
from telethon import events
from telethon.tl.custom import Button

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    # 1. AMBIL DATA USER
    sender = await event.get_sender()
    full_name = f"{sender.first_name} {sender.last_name or ''}".strip()
    user_id = sender.id

    # 2. VALIDASI AKSES
    val = valid(str(user_id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    elif val == "true":
        # KIRIM PESAN LOADING DULU (Agar tidak dikira hank)
        msg_loading = None
        try:
            # Jika tombol (callback), edit pesan
            msg_loading = await event.edit("⏳ **Mohon Tunggu...**")
        except:
            # Jika ketik /start, kirim pesan baru
            msg_loading = await event.reply("⏳ **Mohon Tunggu...**")

        # 3. AMBIL DATA SERVER (DENGAN ANTI-LAG / TIMEOUT)
        try:
            # -- OS NAME --
            # Mengambil nama OS
            os_cmd = "grep -w PRETTY_NAME /etc/os-release | cut -d = -f 2 | tr -d '\"'"
            namaos = subprocess.check_output(os_cmd, shell=True).decode("utf-8").strip()

            # -- IP VPS --
            # Tambahkan --max-time 2 agar tidak macet jika internet lambat
            ipvps = "curl --max-time 2 -s ipv4.icanhazip.com"
            ipsaya = subprocess.check_output(ipvps, shell=True).decode("utf-8").strip()

            # -- CITY & ISP --
            # Cek File Lokal Dulu (Lebih Cepat)
            try:
                city = subprocess.check_output("cat /root/.info/.city", shell=True).decode("utf-8").strip()
            except:
                city = "Unknown"
            
            try:
                isp = subprocess.check_output("cat /root/.info/.isp", shell=True).decode("utf-8").strip()
            except:
                # Fallback ke API dengan Timeout 2 detik
                try:
                    isp = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('isp', 'Unknown'))\"", shell=True).decode("utf-8").strip()
                except:
                    isp = "Unknown"
                
                # Jika City masih unknown, coba ambil via API sekalian
                if city == "Unknown":
                    try:
                        city = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('city', 'Unknown'))\"", shell=True).decode("utf-8").strip()
                    except:
                        city = "Unknown"

        except Exception:
            # Jika error parah, pakai default value biar bot tetap jalan
            namaos = "Ubuntu"
            ipsaya = "Unknown"
            city = "Unknown"
            isp = "Unknown"

        # 4. TOMBOL (Sesuai Request)
        inline = [
            [Button.inline("PANEL CREATE ACCOUNT","menu")],
            [Button.url("CHANNEL","https://t.me/hokagelegend1"),
             Button.url("ORDER SCRIPT","https://t.me/hokagelegend1")]
        ]

        # 5. TAMPILAN PREMIUM
        msg = f"""
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>🟢 HOKAGE PREMIUM TUNNELING</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>👤 USER INFORMATION</b>
<code>🆔 ID       :</code> <code>{user_id}</code>
<code>👤 NAME     :</code> <code>{full_name}</code>
<code>💎 STATUS   :</code> <code>Premium Owner</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>🖥️ SERVER INFORMATION</b>
<code>⚙️ OS       :</code> <code>{namaos}</code>
<code>🌍 LOCATION :</code> <code>{city}</code>
<code>🚀 ISP      :</code> <code>{isp}</code>
<code>🌐 DOMAIN   :</code> <code>{DOMAIN}</code>
<code>📶 IP VPS   :</code> <code>{ipsaya}</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>🤖 @HokageLegend</b>
"""
        
        # Kirim Pesan Final (Update pesan loading tadi)
        try:
            await msg_loading.edit(msg, buttons=inline, parse_mode='html')
        except:
            # Jaga-jaga jika msg_loading gagal
            await event.reply(msg, buttons=inline, parse_mode='html')