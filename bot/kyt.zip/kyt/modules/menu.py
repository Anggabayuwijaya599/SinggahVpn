from kyt import *
import subprocess
import json
from telethon import events
from telethon.tl.custom import Button

# Pastikan function valid() dan variable DOMAIN sudah tersedia dari kyt.py

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # 1. AMBIL DATA USER TELEGRAM
    sender = await event.get_sender()
    full_name = f"{sender.first_name} {sender.last_name or ''}".strip()
    user_id = sender.id
    
    # Cek Validasi Akses
    val = valid(str(user_id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    elif val == "true":
        # 2. AMBIL DATA SYSTEM
        try:
            # -- SSH --
            sh_cmd = "awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l"
            ssh = subprocess.check_output(sh_cmd, shell=True).decode("utf-8").strip()

            # -- VMESS --
            vm_cmd = 'vmc=$(grep -c -E "^### " "/etc/xray/config.json"); echo $((vmc / 2))'
            vms = subprocess.check_output(vm_cmd, shell=True).decode("utf-8").strip()

            # -- VLESS --
            vl_cmd = 'vlx=$(grep -c -E "^#& " "/etc/xray/config.json"); echo $((vlx / 2))'
            vls = subprocess.check_output(vl_cmd, shell=True).decode("utf-8").strip()

            # -- TROJAN --
            tr_cmd = 'trx=$(grep -c -E "^#! " "/etc/xray/config.json"); echo $((trx / 2))'
            trj = subprocess.check_output(tr_cmd, shell=True).decode("utf-8").strip()
            
            # -- OS NAME --
            os_cmd = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g' | sed 's/\"//g'"
            namaos = subprocess.check_output(os_cmd, shell=True).decode("utf-8").strip()

            # -- IP VPS --
            ipvps = "curl -s ipv4.icanhazip.com"
            ipsaya = subprocess.check_output(ipvps, shell=True).decode("utf-8").strip()

            # -- CITY & ISP --
            try:
                city = subprocess.check_output("cat /root/.info/.city", shell=True).decode("utf-8").strip()
            except:
                city = "Unknown"
            
            try:
                isp = subprocess.check_output("cat /root/.info/.isp", shell=True).decode("utf-8").strip()
            except:
                # Fallback API
                isp = subprocess.check_output("curl -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('isp', 'Unknown'))\"", shell=True).decode("utf-8").strip()

        except Exception as e:
            ssh = vms = vls = trj = "0"
            namaos = "Ubuntu"
            ipsaya = "127.0.0.1"
            city = "Unknown"
            isp = "Unknown"

        # 3. BUTTONS (SUDAH ADA TOMBOL KEMBALI)
        inline = [
            [Button.inline("SSH OVPN","ssh"), Button.inline("VMESS","vmess")],
            [Button.inline("VLESS","vless"), Button.inline("TROJAN","trojan")],
            [Button.inline("SHADOWSOCKS","shadowsocks"), Button.inline("SETTING","setting")],
            [Button.inline("CHECK SERVICE","info")],
            # Tombol Refresh & Back Menu sejajar
            [Button.inline("🔄 Refresh","menu"), Button.inline("‹ Back Menu ›","start")]
        ]

        # 4. TAMPILAN DASHBOARD
        msg = f"""
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>🟢 ADMIN DASHBOARD PANEL</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>👤 USER INFORMATION</b>
<code>🆔 ID       :</code> <code>{user_id}</code>
<code>👤 NAME     :</code> <code>{full_name}</code>
<code>💎 STATUS   :</code> <code>Premium Owner</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>🖥️ SERVER INFORMATION</b>
<code>⚙️ OS       :</code> <code>{namaos}</code>
<code>🌍 CITY     :</code> <code>{city}</code>
<code>🚀 ISP      :</code> <code>{isp}</code>
<code>🌐 DOMAIN   :</code> <code>{DOMAIN}</code>
<code>📶 IP VPS   :</code> <code>{ipsaya}</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>📊 ACCOUNT MANAGER</b>
<code>🟢 SSH OVPN    :</code> <code>{ssh} Account</code>
<code>🟢 XRAY VMESS  :</code> <code>{vms} Account</code>
<code>🟢 XRAY VLESS  :</code> <code>{vls} Account</code>
<code>🟢 XRAY TROJAN :</code> <code>{trj} Account</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>🤖 @HokageLegend</b>
"""
        
        try:
            await event.edit(msg, buttons=inline, parse_mode='html')
        except Exception:
            await event.reply(msg, buttons=inline, parse_mode='html')